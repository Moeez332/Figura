const team = document.querySelector('.our-team')
fetch('/team.html')
.then(res=>res.text())
.then(data=>{
    team.innerHTML=data
})